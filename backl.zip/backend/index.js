const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const routes = require("./routes/routes");
const app = express();

app.use(cookieParser());
app.use(express.json());
app.use(
  cors({
    credentials: true,
    origin: ["http://localhost:4200"],
  })
);

app.use("/api", routes);

app.listen(5000, () => {
  console.log("App is listening on port 5000");
});

mongoose
  .connect("mongodb://0.0.0.0:27017/db_users")
  .then(() => {
    console.log("connected to mongo db_users");
  })
  .catch((error) => {
    console.log(error);
  });


