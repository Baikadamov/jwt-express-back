const { Router } = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/user");
const Author = require("../models/author");
const Book = require("../models/book");
const { log } = require("console");
const router = Router();

const mongoose = require('mongoose')

router.post("/register", async (req, res) => {
  // res.send("created user")
  let email = req.body.email;
  let password = req.body.password;
  let name = req.body.name;

  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(password, salt);

  const check_user = await User.findOne({ email: email });

  if (check_user) {
    return res.status(400).send({
      message: "Email is already taken ",
    });
  } else {
    const user = new User({
      name: name,
      email: email,
      password: hashedPassword,
    });

    const result = await user.save();

    //jwt token

    const { _id } = await result.toJSON();
    const token = jwt.sign({ _id: _id }, "secret");
    res.cookie("jwt", token, {
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000,
    });

    res.send({
      message: "Success",
    });
  }
});

router.post("/login", async (req, res) => {
  const user = await User.findOne({ email: req.body.email });

  if (!user) {
    return res.status(404).send({
      message: "User not found",
    });
  }
  if (!(await bcrypt.compare(req.body.password, user.password))) {
    return res.status(400).send({
      message: "Password is incorecct",
    });
  }

  const token = jwt.sign({ _id: user._id }, "secret");

  res.cookie("jwt", token, {
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000,
  });

  res.send({
    message: "success",
    toke: token,
  });
});

router.get("/user", async (req, res) => {
  try {
    const cookie = req.cookies["jwt"];
    const claims = jwt.verify(cookie, "secret");

    if (!claims) {
      return res.status(401).send({
        message: "unauthentifacated",
      });
    }
    const user = await User.findOne({ _id: claims._id });
    const { password, ...data } = await user.toJSON();
    res.send(data);
  } catch (err) {
    return res.status(401).send({
      message: "unauthentifacated",
    });
  }
});

router.post("/logout", (req, res) => {
  res.cookie("jwt", "", { maxAge: 0 });
  res.send({
    message: "Success",
  });
});



//crud authors
//create author 
router.post("/create-author", async (req, res) => {
  if (!req.headers.authorization) {
    return res.status(401).json({ error: "Unauthorized - Token is missing" });
  }

  const token = req.headers.authorization.split(" ")[1];
  try {
    const cookie = req.cookies["jwt"];
    const claims = jwt.verify(cookie, "secret");
    if (!claims) {
      return res.status(401).send({
        message: "unauthentifacated",
      });
    }

    const check_author = await Author.findOne({ name: req.body.name });
    if (!check_author) {
      await Author.create({
        name: req.body.name,
      }).then(() => {
        res.send({ message: "Success" });
      });
    } else {
      res.status(400).send({ error: "Name is already in use!" });
    }
  } catch (error) {
    console.log(error);
    return res.status(401).send({
      message: "unauthentifacated",
    });
  }
});





//get all authors
router.get("/authors", async (req, res) => {
  if (!req.headers.authorization) {
    return res.status(401).json({ error: "Unauthorized - Token is missing" });
  }

  const token = req.headers.authorization.split(" ")[1];

  if (!token) {
    return res.status(401).json({ error: "Unauthorized - Token is missing" });
  }

  try {
    const cookie = req.cookies["jwt"];
    const claims = jwt.verify(cookie, "secret");
    if (!claims) {
      return res.status(401).send({
        message: "unauthentifacated",
      });
    }
    const authors = await Author.find({});
    if (authors) {
      res.send({ authors: authors });
    } else {
      res.send({ error: "Nothing here" });
    }
  } catch (error) {
    console.log(error);
    return res.status(401).send({
      message: "unauthentifacated",
    });
  }
});

router.put("/update-author",async(req,res)=>{
  try {
    const id = new mongoose.Types.ObjectId(req.body.id);
    const author = await Author.findById(id);
    if (author != null) {
      await author.updateOne({
        name: req.body.name, 
      }).then(() => {
        res.send({ message: 'Author is updated successfully!' });
      });
    } else {
      res.status(404).send({ error: 'author is not found!' });
    }
  } catch (error) {
    console.log(error);;
  }
})


router.delete("/delete-author",async(req,res)=>{
  try {
    const id = new mongoose.Types.ObjectId(req.body.id);
    const author = await Author.findById(id);
    if (author == null) {
      res.json({ message: "Author not found" });
    } else {
      await Author.deleteOne(id).then((err) => {
        if (err != null) {
          res.send(err);
        } else {
          res.json({ message: "Author is deleted successfully" });
        }
      });
    }
  } catch (error) {
    console.log(error);;
  }
})


//Books crud
router.get("/getAllBooks",async(req,res)=>{
  const books = await Book.find({});
    if (books) {
      res.send({ books: books });
    } else {
      res.send({ error: "Nothing here" });
    }
})

router.post("/create-book",async(req,res)=>{
  
})



module.exports = router;
